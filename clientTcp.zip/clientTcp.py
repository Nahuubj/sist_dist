import socket
import psutil as pct
import json
import threading 
import time

def get_ram_memory():
    mem = pct.virtual_memory()
    return mem.total

def get_ip_address():
    host_name = socket.gethostname()
    my_ip = socket.gethostbyname(host_name)
    return my_ip


def main():
    host = '192.168.0.169'
    port = 5700

    

    my_disk = pct.disk_usage('C:')
    
    my_usage_disk = my_disk.used
    my_free_disk = my_disk.free
    my_storage = my_disk.total

    ip = get_ip_address()
    ram = get_ram_memory()

    data = {
        "id": 4,
        #"clientName": 'El Alto',
        "totalDisk": my_storage,
        "diskUsage": my_usage_disk,
        "diskFree": my_free_disk,
        "ipAddress": ip,
        "ramMemory": ram
    }

    json_data = json.dumps(data)

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        sock.connect((host, port))

        sock.sendall(json_data.encode())
    finally:
        sock.close()

def run_main_every_5_seconds():
    while True:
        main()
        time.sleep(1)

thread = threading.Thread(target=run_main_every_5_seconds)
thread.start()

thread.join()