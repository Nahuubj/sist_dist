﻿using Newtonsoft.Json;
using practica_sistemasDistribuidos.Models;
using practica_sistemasDistribuidos.Services;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace practica_sistemasDistribuidos.Server
{
    public class TCPListener
    {
        static Socket? server;
        Dictionary<Socket, Thread> clientThreads = new();

        internal readonly List<ConnectedClient> connectedClients = new()
        {
            new ConnectedClient(){Id = 1, ClientName="Oruro"},
            new ConnectedClient(){Id = 2, ClientName="La Paz"},
            new ConnectedClient(){Id = 3, ClientName="Santa Cruz"},
            new ConnectedClient(){Id = 4, ClientName="Beni"},
            new ConnectedClient(){Id = 5, ClientName="Tarija"},
            new ConnectedClient(){Id = 6, ClientName="Pando"},
            new ConnectedClient(){Id = 7, ClientName="Cochabamba"},
            new ConnectedClient(){Id = 8, ClientName="Chuquisaca"},
            new ConnectedClient(){Id = 9, ClientName="Potosi"}
        };

        public TCPListener()
        {
            string ip = "192.168.0.169";
            int port = 5700;

            IPAddress ipAddress = IPAddress.Parse(ip);

            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            server.Bind(new IPEndPoint(ipAddress, port));
            server.Listen(15);

            Console.WriteLine("Servidor iniciado...");
            Thread clientThread = new Thread(() => ListenClients());
            clientThread.Start();
        }

        void ListenClients()
        {
            while (true)
            {
                Socket clientSocket = server!.Accept();
                Thread clientThread = new Thread(() => HandleClient(clientSocket));
                clientThreads[clientSocket] = clientThread;
                clientThread.Start();
            }
        }

        void HandleClient(Socket socketClient)
        {
            ClientTcpService clientService = new(this);
            byte[] buffer = new byte[1024];
            int bytesRead = socketClient.Receive(buffer);
            
            string dataReceived = Encoding.ASCII.GetString(buffer, 0, bytesRead);

            var getClient = JsonConvert.DeserializeObject<ConnectedClient>(dataReceived);

            

            var searchClient = connectedClients.Find(x => x.ClientName.Equals(getClient.ClientName));

             if(getClient!.Id > 0 || connectedClients.Contains(searchClient))
                clientService.PowerOnClient(getClient);
            else
            {
                getClient.Id = connectedClients.Count + 1;
                connectedClients.Add(getClient!);
                clientService.PowerOnClient(getClient);
            }

            clientService.GetStorageInGB(getClient);

            Console.WriteLine(JsonConvert.SerializeObject(getClient));

            socketClient.Shutdown(SocketShutdown.Both);
            socketClient.Close();
        }

        public List<ConnectedClient> GetClients()
        {
            return connectedClients;
        }
    }
}