'use client';
import React from "react";
import { useEffect, useState } from "react";
import Card from "./components/cards";

function Home() {
  const [servers, setServers] = useState([]);

  useEffect(() => {
    const interval = setInterval(() => {
      fetch("http://localhost:5168/api/Tcp/GetClients")
        .then((response) => response.json())
        .then((data) => { setServers(data); console.log(data); })
        .catch((error) => { console.error('Error al obtener los datos:', error); });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main>
      <div className="rounded bg-white p-8">
        <div className="flex text-gray-600 text-xl font-semibold justify-center">
          SERVIDORES
        </div>
        <Card dataServers={servers}></Card>
      </div>
    </main>
  );
}

export default Home;