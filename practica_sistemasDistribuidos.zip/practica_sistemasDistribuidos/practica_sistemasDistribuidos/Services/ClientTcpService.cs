﻿using practica_sistemasDistribuidos.Models;
using practica_sistemasDistribuidos.Server;

namespace practica_sistemasDistribuidos.Services
{
    public class ClientTcpService
    {
        private readonly TCPListener _server;

        public ClientTcpService(TCPListener server)
        {
            _server = server;
        }

        internal void PowerOnClient(ConnectedClient client)
        {
            var searchClientByIndex = _server.connectedClients.FindIndex(c => c.Id == client.Id);
            if (searchClientByIndex != -1)
            {
                client.Status = 1;
                if (client.ClientName == null || client.ClientName == string.Empty)
                {
                    client.ClientName = _server.connectedClients[searchClientByIndex].ClientName;
                }
                _server.connectedClients[searchClientByIndex] = client;
            }
        }

        internal void PowerOffClient(List<ConnectedClient> connectedClients)
        {
            connectedClients.ForEach(client => client.Status = 0);
        }

        internal void GetStorageInGB(ConnectedClient client)
        {
            client.RamMemory = Math.Round(ConvertBytesToGB(client.RamMemory), 3);
            client.DiskFree = Math.Round(ConvertBytesToGB(client.DiskFree), 3);
            client.DiskUsage = Math.Round(ConvertBytesToGB(client.DiskUsage), 3);
            client.TotalDisk = Math.Round(ConvertBytesToGB(client.TotalDisk), 3);
        }

        private double ConvertBytesToGB(double source)
        {
            return source / Math.Pow(1024, 3); //Pow() eleva 1024 a la 3
        }
    }
}