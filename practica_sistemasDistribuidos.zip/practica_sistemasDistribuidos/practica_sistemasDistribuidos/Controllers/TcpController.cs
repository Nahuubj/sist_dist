﻿using Microsoft.AspNetCore.Mvc;
using practica_sistemasDistribuidos.Models;
using practica_sistemasDistribuidos.Server;

namespace practica_sistemasDistribuidos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TcpController : ControllerBase
    {
        private readonly TCPListener _tcpListener;

        public TcpController(TCPListener tCPListener)
        {
            _tcpListener = tCPListener;
        }

        [HttpGet, Route("GetClients")]
        public ActionResult<List<ConnectedClient>> GetClients()
        {
            var clients = _tcpListener.GetClients(); 
            return Ok(clients);
        }
    }
}