"use client";
import React, { useState, useEffect } from "react";
import { Montserrat } from "next/font/google";
import "./globals.css";

const montserrat = Montserrat({ subsets: ["latin"] });


export default function RootLayout({ children }) {
  const [currentTime, setCurrentTime] = useState(
    new Date().toLocaleTimeString()
  );
  const [currentDate, setCurrentDate] = useState(
    new Date().toLocaleDateString()
  );
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTime(new Date().toLocaleTimeString());
      setCurrentDate(new Date().toLocaleDateString());
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  return (
    <html lang="en">
      <body className={montserrat.className}>
        <div className='mainHeader'>
          Almacenamientos Registrados
          <div className='headerContent'>
            74 TB - 65 En Uso - 83776 GB Libre
            <div className='mod'>
              {currentTime} | {currentDate}
            </div>
            <div>
              Todos los storages deberian tener 5TB
            </div>
          </div>
        </div>
        {children}
      </body>
    </html>
  );
}
