﻿namespace practica_sistemasDistribuidos.Models
{
    public class ConnectedClient
    {
        public int Id { get; set; }
        public string ClientName { get; set; }
        public double TotalDisk { get; set; }
        public double DiskUsage { get; set; }
        public double DiskFree { get; set; }
        public string IpAddress { get; set; }
        public double RamMemory { get; set; }
        public byte Status { get; set; } = 0;
    }
}