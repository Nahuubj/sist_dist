"use client";
import React, { useState, useEffect } from 'react';


const Cards = ({ dataServers }) => {
    console.log(dataServers)
    const [servers, setServers] = useState([]);
    const [currentTime, setCurrentTime] = useState(new Date().toLocaleTimeString());
    const [currentDate, setCurrentDate] = useState(new Date().toLocaleDateString());

    const [totalDiskUsage, setTotalDiskUsage] = useState(0);
    const [totalDiskFree, setTotalDiskFree] = useState(0);

    const [sumTotalFree, setSumTotalFree] = useState(0);
    const [sumTotalDiskUsage, setSumTotalDiskUsage] = useState(0);

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentTime(new Date().toLocaleTimeString());
            setCurrentDate(new Date().toLocaleDateString());
        }, 1000);
        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        const interval = setInterval(() => {
            let totalDisk = 0;
            let totalDiskUsage = 0;
            let totalDiskFree = 0;

            const summedServers = dataServers.reduce((acc, server) => {
                if (server.status === 1) {
                    const existingServer = acc.find(s => s.id === server.id && s.status === 1);
                    if (existingServer) {
                        existingServer.totalDisk += server.totalDisk;
                        existingServer.diskUsage += server.diskUsage;
                        existingServer.diskFree += server.diskFree;
                    } else {
                        acc.push({ ...server });
                    }

                    totalDisk += server.totalDisk;
                    totalDiskUsage += server.diskUsage;
                    totalDiskFree += server.diskFree;
                    const totalDiskUsagePercentage = (totalDiskUsage / totalDisk) * 100;
                    const totalDiskFreePercentage = (totalDiskFree / totalDisk) * 100;

                    setTotalDiskUsage(totalDiskUsagePercentage);
                    setTotalDiskFree(totalDiskFreePercentage);
                } else {
                    acc.push({ ...server });
                }
                return acc;
            }, []);

            // Actualizar la suma total de uso de disco y espacio libre
            setSumTotalDiskUsage(totalDiskUsage);
            setSumTotalFree(totalDiskFree);

            setServers(summedServers);
        }, 1000);

        // Limpiar el intervalo cuando el componente se desmonte
        return () => clearInterval(interval);
    }, [dataServers]);

    return (
        <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row justify-between items-center py-6">
                <p className="text-gray-700 text-lg md:text-xl font-semibold">
                    Espacio Usado: {totalDiskUsage.toFixed(2)}%
                </p>
                <p className="text-gray-700 text-lg md:text-xl font-semibold">
                    Espacio Libre: {totalDiskFree.toFixed(2)}%
                </p>
                <p className="text-gray-700 text-lg md:text-xl font-semibold">
                    Espacio Total Usado: {sumTotalDiskUsage.toFixed(2)} GB
                </p>
                <p className="text-gray-700 text-lg md:text-xl font-semibold">
                    Espacio Total Disponible: {sumTotalFree.toFixed(2)} GB
                </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {servers.length > 0 ? (
                    servers.map(server => (
                        <div className="max-w-sm rounded overflow-hidden shadow-lg" key={server.id}>
                            <img className="w-full h-64 object-cover" src="https://illustoon.com/photo/thum/7823.png" alt="Sunset in the mountains" />
                            <div className="px-6 py-4 text-center">
                                <div className="font-bold text-xl text-black mb-2">{server.nombre}</div>
                                {server.status === 1 ? (
                                    <>
                                        <p className="text-blue-700 text-base text-xl font-bold">
                                            {server.clientName}
                                        </p>
                                        <p className="text-gray-700 text-base">
                                            {server.totalDisk} GB Total
                                        </p>
                                        <p className="text-gray-700 text-base">
                                            {server.diskUsage} GB En Uso
                                        </p>
                                        <p className="text-gray-700 text-base">
                                            {server.diskFree} GB Libre
                                        </p>
                                        <p className="text-red-700 text-base font-bold">
                                            Porcentaje de uso: {(server.diskUsage / (5 * 1024) * 100).toFixed(2)}%
                                        </p>
                                        <div className='flex justify-center'>
                                            <p className="text-blue-700 text-base px-1 font-bold">
                                                Hora: {currentTime}
                                            </p>
                                            <p className="text-blue-700 text-base px-1 font-bold">
                                                Fecha: {currentDate}
                                            </p>
                                        </div>
                                        <p className="text-gray-700 text-base font-bold">
                                            IP: {server.ipAddress}
                                        </p>
                                        <p className="text-gray-700 text-base font-bold">
                                            RAM: {server.ramMemory}
                                        </p>
                                    </>
                                ) : (
                                    <div>
                                        <p className="text-red-500 font-bold text-xl">
                                            {server.clientName}
                                        </p>
                                        <p className="text-red-500">No está conectado</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-red-500">No hay servidores disponibles</p>
                )}
            </div>
        </div>
    );
};

export default Cards;